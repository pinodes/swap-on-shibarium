import { Modal } from '../Dialog'

function Fixture() {
  return null
  // TODO(zzmp): Mock <StatusDialog tx={} onClose={() => void 0} />
}

export default (
  <Modal color="dialog">
    <Fixture />
  </Modal>
)
